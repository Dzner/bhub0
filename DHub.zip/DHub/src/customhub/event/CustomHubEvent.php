<?php

namespace customhub\event;

use pocketmine\Server;
use pocketmine\Player;
use pocketmine\event\Event;
use pocketmine\event\Cancellable;
use pocketmine\plugin\PluginBase;

class CustomHubEvent extends Event implements Cancellable {

	/** @var Player */
	private $player;

	/**
	* @param Player $player
	*/
	public function __construct(Player $player) {
		$this->player = $player;
	}

	/**
	* @return Player
	*/
	public function getPlayer() : Player {
		return $this->player;
	}
}