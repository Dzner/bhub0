<?php

namespace customhub\command;

use pocketmine\Server;
use pocketmine\Player;
use pocketmine\level\Position;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use customhub\event\CustomHubEvent;

class HubCommand extends Command {

	/** @var bool */
	public static $invClear = false;
	public static $armorClear = false;
	public static $effectClear = false;

	/** @var Position/null */
	public static $position;

	/** @var string */
	public static $message = "";
	public static $Title = "";
	public static $subTittle = "";

	/**
	* @param string $description
	* @param string $usage
	* @param array  $alias
	* @author Dzenr
	*/
	public function __construct(string $description, string $usage, array $alias){
		parent::__construct("bhub", $description, $usage, $alias);
		$this->setPermission("back.hub");
	}

	/**
	* @param CommandSender $description
	* @param string        $usage
	* @param array         $alias
	* @author Dzenr
	*/
	public function execute(CommandSender $sender, string $commandLabel, array $args){
		if ($this->testPermission($sender)) {
			if ($sender instanceof Player) {
				$event = new CustomHubEvent($sender);
				if ($event->isCancelled()) {
					return true;
				}
				$event->call();
				if (self::$position instanceof Position) {
					$sender->teleport(self::$position);
				}else{
					$sender->teleport(Server::getInstance()->getDefaultLevel()->getSafeSpawn());
				}
				if (self::$invClear) {
					$sender->getInventory()->clearAll();
		
				}
				if (self::$armorClear) {
					$sender->getArmorInventory()->clearAll();
				}
				if (self::$effectClear) {
					$sender->removeAllEffects();
				}
				$sender->sendMessage(self::$message);
				$sender->addTitle(self::$Title, self::$subTittle);
			}
		}
		return true;
	}

	/**
	* @param string $description
	* @param string $usage
	* @param string $alias
	* @author Dzenr
	*/
	public static function setMessage(string $message = "", string $title = "", string $subtitle = "") {
		self::$message = $message;
		self::$Title = $title;
		self::$subTittle = $subtitle;
	}

	/**
	* @param string $description
	* @param string $usage
	* @param string $alias
	* @author Dzenr
	*/
	public static function setClear(bool $invClear = false, bool $armorClear = false, bool $effectClear = false) {
		self::$invClear = $invClear;
		self::$armorClear = $armorClear;
		self::$effectClear = $effectClear;
	}
}