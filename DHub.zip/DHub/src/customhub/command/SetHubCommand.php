<?php

namespace customhub\command;

use pocketmine\Server;
use pocketmine\Player;
use pocketmine\utils\Config;
use pocketmine\level\Location;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;

class SetHubCommand extends Command {

	/** @var CustomHub */
	private $plugin;

	/**
	* @author Dzenr
	*/
	public function __construct($plugin){
		$this->plugin = $plugin;
		parent::__construct("shub", "make position for hub", "");
		$this->setPermission("customhub.sethub");
	}

	/**
	* @param CommandSender $description
	* @param string        $usage
	* @param array         $alias
	* @author DarkByx
	*/
	public function execute(CommandSender $sender, string $commandLabel, array $args){
		if ($this->testPermission($sender)) {
			if ($sender instanceof Player) {
				$pos = [$sender->getFloorX(), $sender->getFloorY(), $sender->getFloorZ()];
				$motion = $sender->getLocation();
				$yaw = $motion->getYaw();
				$pitch = $motion->getPitch();
				$world = $sender->getLevel()->getFolderName();
				$config = new Config($this->plugin->getDataFolder().'config.yml', Config::YAML);
				$config->set("Yaw", $yaw);
				$config->set("Pitch", $pitch);
				$config->set("World", $world);
				$config->set("Pos", $pos);
				$config->save();
				$location = new Location($pos[0], $pos[1], $pos[2], $yaw, $pitch, $sender->getLevel());
				HubCommand::$position = $location;
				$sender->sendMessage("§7§oHub moved here!");
			}
		}
		return true;
	}
}