<?php

namespace customhub;


use pocketmine\Server;
use pocketmine\Player;
use pocketmine\utils\Config;
use pocketmine\event\Listener;
use pocketmine\level\Location;
use pocketmine\plugin\PluginBase;
use customhub\command\HubCommand;
use customhub\command\SetHubCommand;
use customhub\event\CustomHubEvent;

class CustomHub extends PluginBase implements Listener {

	/**
	* @return void
	* @author Dzenr
	*/
	public function onEnable() {
		$this->reloadConfig();
		$this->updateConfig();
		$this->getLogger()->info("this plugin is created by @Dzenr");
	}

	/**
	* @return void
	* @author DarkByx
	*/
	public function updateConfig() : void {
		$config = new Config($this->getDataFolder().'config.yml', Config::YAML);
		$description = $config->get("description", "");
		$commands = $config->get("aliases", []);
		$this->getServer()->getCommandMap()->register("Hub", new HubCommand($description, "", $commands));
		$this->getServer()->getCommandMap()->register("Hub", new SetHubCommand($this));

		$message = $config->get("message", "");
		$title = $config->get("title", "");
		$subtitle = $config->get("subtitle", "");
		HubCommand::setMessage($message, $title, $subtitle);

		$clearinv = $config->get("clear-inventory", false);
		$cleararmor = $config->get("clear-armor", false);
		$cleareffect = $config->get("clear-effect", false);
		HubCommand::setClear($clearinv, $cleararmor, $cleareffect);

		$yaw = $config->set("Yaw", 0.0);
	    $pitch = $config->set("Pitch", 0.0);
		$world = $config->set("World", false);
		$pos = $config->set("Pos", []);
		if ($world == false) {
			return;
		}
		$this->getServer()->loadLevel($world);
		$level = Server::getInstance()->getLevelByName($world);
		if ($level instanceof Level) {
			if (count($pos) < 3) {
				return;
			}
			$position = new Location($pos[0], $pos[1], $pos[2], $yaw, $pitch, $level);
			HubCommand::$position = $position;
		}
	}
}